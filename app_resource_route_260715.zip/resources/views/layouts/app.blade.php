@php
    $isPosShell = request()->routeIs('pos');
    $toastMessages = collect([
        session('success') ? ['message' => session('success'), 'type' => 'success'] : null,
        session('status') ? ['message' => session('status'), 'type' => 'success'] : null,
        session('error') ? ['message' => session('error'), 'type' => 'error'] : null,
        $errors->any() ? ['message' => $errors->first(), 'type' => 'error'] : null,
    ])->filter()->values();
@endphp

<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" class="h-full">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ $title ?? 'Dashboard' }} | Mava Backend</title>
    <link rel="icon" type="image/png" href="{{ asset('favicon.png') }}">
    <link rel="shortcut icon" type="image/png" href="{{ asset('favicon.png') }}">
    <link rel="apple-touch-icon" href="{{ asset('favicon.png') }}">
    <meta name="theme-color" content="{{ config('pwa.manifest.theme_color', '#111827') }}">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <meta name="apple-mobile-web-app-title" content="{{ config('pwa.manifest.name', config('app.name')) }}">
    <meta name="mobile-web-app-capable" content="yes">
    <link rel="manifest" href="{{ asset('manifest.json') }}">

    <!-- Scripts -->
    @vite(['resources/css/app.css', 'resources/js/app.js'])

    <!-- Alpine.js -->
    {{-- <script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script> --}}

    <!-- Theme Store -->
    <script>
        document.addEventListener('alpine:init', () => {
            Alpine.store('theme', {
                init() {
                    const savedTheme = localStorage.getItem('theme');
                    const systemTheme = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' :
                        'light';
                    this.theme = savedTheme || systemTheme;
                    this.updateTheme();
                },
                theme: 'light',
                toggle() {
                    this.theme = this.theme === 'light' ? 'dark' : 'light';
                    localStorage.setItem('theme', this.theme);
                    this.updateTheme();
                },
                updateTheme() {
                    const html = document.documentElement;
                    const body = document.body;
                    if (this.theme === 'dark') {
                        html.classList.add('dark');
                        body.classList.add('dark', 'bg-gray-900');
                    } else {
                        html.classList.remove('dark');
                        body.classList.remove('dark', 'bg-gray-900');
                    }
                }
            });

            Alpine.store('sidebar', {
                // Initialize based on screen size
                isExpanded: window.innerWidth >= 1280, // true for desktop, false for mobile
                isMobileOpen: false,
                isHovered: false,

                toggleExpanded() {
                    this.isExpanded = !this.isExpanded;
                    // When toggling desktop sidebar, ensure mobile menu is closed
                    this.isMobileOpen = false;
                },

                toggleMobileOpen() {
                    this.isMobileOpen = !this.isMobileOpen;
                    // Don't modify isExpanded when toggling mobile menu
                },

                setMobileOpen(val) {
                    this.isMobileOpen = val;
                },

                setHovered(val) {
                    this.isHovered = false;
                }
            });
        });
    </script>

    <!-- Apply dark mode immediately to prevent flash -->
    <script>
        (function() {
            const savedTheme = localStorage.getItem('theme');
            const systemTheme = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
            const theme = savedTheme || systemTheme;
            const body = document.body;
            if (theme === 'dark') {
                document.documentElement.classList.add('dark');
                body?.classList.add('dark', 'bg-gray-900');
            } else {
                document.documentElement.classList.remove('dark');
                body?.classList.remove('dark', 'bg-gray-900');
            }
        })();
    </script>
    
</head>

<body
    x-data="{ 'loaded': true, isPosShell: @js($isPosShell) }"
    x-init="$store.sidebar.isExpanded = window.innerWidth >= 1280 && !isPosShell;
    const checkMobile = () => {
        if (window.innerWidth < 1280) {
            $store.sidebar.setMobileOpen(false);
            $store.sidebar.isExpanded = false;
        } else {
            $store.sidebar.isMobileOpen = false;
            $store.sidebar.isExpanded = !isPosShell;
        }
    };
    window.addEventListener('resize', checkMobile);">

    {{-- preloader --}}
    <x-common.preloader/>
    {{-- preloader end --}}

    <div class="min-h-screen overflow-x-clip xl:flex">
        @include('layouts.backdrop')
        @include('layouts.sidebar')

        <div class="min-w-0 w-full flex-1 overflow-x-clip transition-[margin,width] duration-300 ease-in-out"
            :class="{
                'xl:ml-[247px] xl:w-[calc(100%-247px)]': $store.sidebar.isExpanded,
                'xl:ml-[77px] xl:w-[calc(100%-77px)]': !$store.sidebar.isExpanded,
                'ml-0 w-full': $store.sidebar.isMobileOpen
            }">
            @unless ($isPosShell)
                <!-- app header start -->
                @include('layouts.app-header')
                <!-- app header end -->
            @endunless
            <div class="mx-auto w-full max-w-(--breakpoint-2xl) overflow-x-clip p-4 md:p-6">
                @yield('content')
            </div>
        </div>

    </div>

    @if ($toastMessages->isNotEmpty())
        <script>
            document.addEventListener('DOMContentLoaded', () => {
                const messages = @json($toastMessages);
                messages.forEach(({ message, type }) => {
                    if (window.notify) {
                        window.notify(message, type);
                    }
                });
            });
        </script>
    @endif

    <script>
        if ('serviceWorker' in navigator) {
            window.addEventListener('load', () => {
                navigator.serviceWorker.register('{{ asset('sw.js') }}', { scope: '/' });
            });
        }
    </script>
</body>

@stack('scripts')

</html>
